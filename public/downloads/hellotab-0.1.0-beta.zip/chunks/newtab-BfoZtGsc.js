import{s as o}from"./index-CnmiwAbJ.js";o.getItem("local:nightly").then(t=>{t?window.location.href="https://nightly.hellotab.top":window.location.href="https://hellotab.top"});
